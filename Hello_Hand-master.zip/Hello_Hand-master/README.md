# Java Script
Hello People, I just used Hand Tracking Libraries to built this. This Detects the Movent of your Hand. I used custom sound, it plays when it detects hand. Its quite unique and fun way of using Hand Detection. This little Web Application is made in JavaScript and with built in Hand Detector Libraries.
Use your own Custom Sound and have fun with your pals.
